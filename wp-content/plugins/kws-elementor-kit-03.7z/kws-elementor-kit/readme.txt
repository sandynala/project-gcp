=== KWS Elementor Kit ===
Contributors: codefiniti, satishpk
Developer link: http://codefiniti.com/
Tags: elementor, posts, post grid, post carousel, post archive, post widget, elementor addon, pagebuilder addon, addons, codefiniti
Stable tag: 1.5.1
Requires PHP: 7.0.0
Requires at least: 4.7.0
Tested up to: 5.8.3
License: GPL3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Elementor requires at least: 3.0.0
Elementor tested up to: 3.5.1

Addon for Elementor WordPress Plugin with Elements for Custom Project
