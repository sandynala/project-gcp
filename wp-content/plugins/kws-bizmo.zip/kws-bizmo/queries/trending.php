<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}


function query_trending_articles( $query ) {
    // Set the custom post type 
    $query->set( 'post_type', [ 'articles' ] ); 

	// Get current meta Query
	$meta_query = $query->get( 'meta_query' );

	// If there is no meta query when this filter runs, it should be initialized as an empty array.
	if ( ! $meta_query ) {
		$meta_query = [];
	}
    
    // add our condition to the meta_query
    $meta_query = array(
        'relation' => 'AND',
        'page_views_count' => array(
            'key'       => 'views_count',
            'compare'   => 'EXISTS',
            'type'      => 'NUMERIC',
        ),
        'page_likes_count' => array(
            'key'       => 'likes_count',
            'compare'   => 'EXISTS',
            'type'      => 'NUMERIC',
        ), 
    );
    

	$query->set( 'meta_query', $meta_query );

    // set the new orderby
    $query->set('orderby', [
        'page_views_count'  => 'DESC',
        'page_likes_count'  => 'DESC',
        'comment_count'     => 'DESC',
    ]);
}

add_action( 'elementor/query/trending_articles', 'query_trending_articles');
add_action( 'kws_elementor_kit_pro/query/trending_articles', 'query_trending_articles');


function query_hero_articles( $query ) {
    // Set the custom post type 
    $query->set( 'post_type', [ 'articles' ] ); 

	// Get current meta Query
	$meta_query = $query->get( 'meta_query' );

	// If there is no meta query when this filter runs, it should be initialized as an empty array.
	if ( ! $meta_query ) {
		$meta_query = [];
	}
    
    // add our condition to the meta_query
    $meta_query = array(
        'page_show_in_homepage' => array(
            'key'       => 'show_in_homepage',
            'compare'   => '=',
            'value'     => '1',
        ),
    );
    

	$query->set( 'meta_query', $meta_query );
}
add_action( 'kws_elementor_kit_pro/query/hero_articles', 'query_hero_articles');