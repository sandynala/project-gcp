<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}



function self_hosted_ad( $atts ) {
    $a = shortcode_atts( array(
        'id' => '2110333a1ca8b36294327fcf0e68fb67',
        'zoneid' => '4',
        'source' => '//sas.happiesthealth.test/www/delivery/asyncjs.php',
    ), $atts );
 
    $output = '<ins data-revive-zoneid="' . esc_attr( $a[zoneid] ) . '" data-revive-id="' . esc_attr( $a['id'] ) . '"></ins><script async src="' . esc_url( $a['source'] ) . '"></script>';
    return $output;
}
add_shortcode( 'ads', 'self_hosted_ad' );
