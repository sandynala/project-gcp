<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}

function admin_default_page() {
  return '/wp-admin';
}

add_filter('login_redirect', 'admin_default_page');