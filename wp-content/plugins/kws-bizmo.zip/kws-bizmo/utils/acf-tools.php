<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}


function hide_acf_field($field) {
  return false;
}
// add_filter("acf/prepare_field/name=views_count", "hide_acf_field");

function hide_readonly_fields() {
    $fields = ["views_count", "share_count", "likes_count", "bookmark_count", "thumbs_up_count", "thumbs_down_count"];
    foreach($fields as $field) {
        add_filter("acf/prepare_field/name=" . $field, "hide_acf_field");
    }
}

hide_readonly_fields();