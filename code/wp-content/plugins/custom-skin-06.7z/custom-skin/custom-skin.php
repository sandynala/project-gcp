<?php
/*
 * Plugin Name: Custom Skin
 * Version: 3.1.4
 * Description: Elementor Custom Skin for Posts and Archive Posts. You can create a skin as you want.
 * Plugin URI: https://codefiniti.com
 * Author: Codefiniti.com
 * Author URI: https://codefiniti.com
 * Text Domain: custom-skin
 * Domain Path: /languages
 * License: GPLv3
 * License URI: http://www.gnu.org/licenses/gpl-3.0
 * Elementor tested up to: 3.5.0
 * Elementor Pro tested up to: 3.5.0
*/


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'CSXKEK_PATH', plugin_dir_path( __FILE__ ));
define( 'CSXKEK_PBNAME', plugin_basename( __FILE__ ));
define( 'CSXKEK_URL', plugin_dir_url( __FILE__ ));
define ('CSXKEK_VER','3.1.4');

include_once CSXKEK_PATH.'dyno/csx-dependencies.php';
include_once CSXKEK_PATH.'dyno/enqueue-styles.php';

include_once CSXKEK_PATH.'dyno/ajax-pagination.php';

//check if Elementor is installed

if (xcs_dependencies()) {
  add_action( 'elementor_pro/init', 'kekcsx_elementor_init' );
  function kekcsx_elementor_init(){

    include_once CSXKEK_PATH.'dyno/admin-bar-menu.php';
    require_once CSXKEK_PATH.'theme-builder/init.php';
    require_once CSXKEK_PATH.'modules/dyno-item/module.php';

  }

  add_action('elementor/widgets/widgets_registered','kekcsx_add_skins');
  function kekcsx_add_skins(){
    require_once CSXKEK_PATH.'skins/skin-custom.php';
  }

  // dynamic background fix
  require_once CSXKEK_PATH.'dyno/dynamic-style.php';

  
} else {
    //$notification = new Ecs_Notice(__( '<b>Custom Skin</b> needs <b>Elementor</b> and <b>Elementor Pro</b> to work. Make sure you have them <b>both</b> installed.', 'csx-dyno' ));
    //$notification->set_type('error');
    //$notification->show();
}
