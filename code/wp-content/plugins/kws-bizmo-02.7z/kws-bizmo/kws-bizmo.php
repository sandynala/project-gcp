<?php

/**
 * Plugin Name: KWS Business Module
 * Plugin URI: https://kwstech.in/
 * Description: Business Module for KWS Website
 * Version: 1.0.0
 * Author: KWS Tech
 * Author URI: https://kwstech.in/
 * Text Domain: kws-bizmo
 * Domain Path: /languages
 */
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

// Some pre define value for easy use
define( 'KWSBIZ_VER', '1.0.0' );
define( 'KWSBIZ__FILE__', __FILE__ );
define( 'KWSBIZ_PATH', plugin_dir_path( KWSBIZ__FILE__ ) );
define( 'KWSBIZ_QUERY_PATH', KWSBIZ_PATH . 'queries/' );
define( 'KWSBIZ_UTILS_PATH', KWSBIZ_PATH . 'utils/' );

define( 'KWSBIZ_KWSES_DIR', KWSBIZ_PATH . 'search/' );

require KWSBIZ_QUERY_PATH . 'queries-init.php';
require KWSBIZ_UTILS_PATH . 'utils-init.php';

require KWSBIZ_KWSES_DIR . 'extended-search.php';
