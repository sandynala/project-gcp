<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}


require_once KWSBIZ_UTILS_PATH . 'post-manger.php';