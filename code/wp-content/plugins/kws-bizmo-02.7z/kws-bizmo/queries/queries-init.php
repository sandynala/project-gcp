<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}

require KWSBIZ_QUERY_PATH . 'trending.php';