<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}


add_action( 'elementor/query/trending_articles', function( $query ) {
    // Set the custom post type 
    $query->set( 'post_type', [ 'articles' ] ); 

	// Get current meta Query
	$meta_query = $query->get( 'meta_query' );

	// If there is no meta query when this filter runs, it should be initialized as an empty array.
	if ( ! $meta_query ) {
		$meta_query = [];
	}
    
    // add our condition to the meta_query
    $meta_query['page_views_count'] = [
        'key'     => 'views_count',
        'compare' => 'EXISTS',
    ];
    $meta_query['page_likes_count'] = [
        'key'     => 'likes_count',
        'compare' => 'EXISTS',
    ];

	$query->set( 'meta_query', $meta_query );

    // set the new orderby
    $query->set('orderby', [
        'comment_count' => 'DESC',
        'page_likes_count' => 'DESC',
        'page_views_count' => 'DESC',
    ]);
} );